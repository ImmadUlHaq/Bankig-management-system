import java.util.ArrayList;
import java.util.Scanner;

public class MainClass {

		public static void main(String[] args) {
	
		Start obj = new Start();
		obj.Home();
	
	}
}
